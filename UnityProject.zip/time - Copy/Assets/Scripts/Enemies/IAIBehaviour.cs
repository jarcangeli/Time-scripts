﻿public interface IAIBehaviour
{
    void Move();
    void Act();

    void Superify();
}
