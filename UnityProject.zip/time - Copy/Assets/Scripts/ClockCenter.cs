﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClockCenter : MonoBehaviour
{
    /*
    void OnTriggerEnter2D(Collider2D collider)
    {
        Debug.Log("Center collided with " + collider.name);
        if (collider.transform.GetComponent<EnemyMovement>() is EnemyMovement enemy)
        {
            enemy.SuckTime();
        }
    }
    */
}
